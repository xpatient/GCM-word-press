GCM Android App
===============

The Android eclipse project for the wordpress plugin wp-gcm (http://wordpress.org/plugins/wp-gcm)

Just download it and import wp-gcm-android to your eclipse workspace, and change the SENDER_ID and URL values.
Thats it, have fun with it!

http://pixelartdev.com - http://twitter.com/pixelartdev - http://facebook.com/pixelartdev.com
